Update package: Externalized controls, Agentic Identity Mesh and semantic decision lineage

Replace:
- root index.html
- pages/box-08-agentic-prodspec-control-contract.html
- pages/box-09-tool-invocation-policy-model.html
- pages/box-10-agent-to-agent-communication-governance.html
- pages/box-19-ephemeral-child-agents.html
- pages/box-22-ephemeral-secrets-workload-lineage.html
- pages/box-23-compute-admission-runtime-integrity.html
- pages/box-24-ephemeral-sandboxing-for-dynamic-execution.html
- pages/box-25-prompt-output-inspection.html
- pages/box-30-output-commitment-control.html
- pages/box-35-policy-constitutional-evaluation.html
- pages/box-36-decision-lineage-evidence-schema.html
- pages/box-38-structured-agentic-telemetry-collection.html
- pages/box-39-correlated-ai-threat-detection-ir.html

Also removes the top navigation Layer -4 Capability Pages link if present and adds the backlog note.
